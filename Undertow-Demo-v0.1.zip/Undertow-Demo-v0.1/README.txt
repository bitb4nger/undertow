UNDERTOW -- demo v0.1
A woodcut tactics game for the Arduboy FX / FX-C. Chapters 1-6 plus two hidden side chapters.

FILES
  Undertow-FX.hex     the game, for the original Arduboy FX (and Ardens with default settings)
  Undertow-FXC.hex    the game, for the Arduboy FX-C (and Ardens with fxport=e2)
  Undertow-data.bin   the game's FX data, for building a flashcart image (pair it with the .hex)
  Undertow-dev.bin    the same data padded for development: drop it on Ardens together with
                      a .hex, or write it to the end of the flash chip with fxdata-upload.py
  screenshots/        pictures

The FX and FX-C wire the flash chip differently: use the .hex that matches your device.
A big X on the screen with the red LED lit means the FX data is missing or the wrong .hex is loaded.

Uploading the .hex directly: the game is built without USB support (to fit), so put the
Arduboy in its bootloader first -- hold UP + DOWN for a moment while the game runs -- then upload.

CONTROLS
  D-pad   move the cursor          A   select / confirm      B   cancel / jump to next ready unit
  A on your unit: show its move range; A again to walk there, then pick an action
  A on an enemy: show where it can reach and strike
  A on an empty tile: END TURN, SOUND, RESTART chapter, QUIT to title
  Hold A during a battle to speed it up. B on a chapter card toggles sound.
